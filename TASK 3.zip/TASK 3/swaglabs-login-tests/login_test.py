from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# 1. Set up Chrome WebDriver
driver = webdriver.Chrome()
driver.get("https://www.saucedemo.com/")
driver.maximize_window()

# 2. Define login function
def login(username, password):
    driver.find_element(By.ID, "user-name").clear()
    driver.find_element(By.ID, "password").clear()
    driver.find_element(By.ID, "user-name").send_keys(username)
    driver.find_element(By.ID, "password").send_keys(password)
    driver.find_element(By.ID, "login-button").click()
    time.sleep(2)

# 3. Improved login check
def is_logged_in():
    return driver.current_url.startswith("https://www.saucedemo.com/inventory.html")

# 4. Reset page before next test
def reset_page():
    driver.get("https://www.saucedemo.com/")
    time.sleep(1)

# ---------- Valid Credentials (6 Tests) ----------
valid_credentials = [
    ("standard_user", "secret_sauce"),
    ("problem_user", "secret_sauce"),  # might pass but buggy
    ("performance_glitch_user", "secret_sauce"),
    ("visual_user", "secret_sauce"),
    ("error_user", "secret_sauce"),
    ("locked_out_user", "secret_sauce")  # should fail
]

print("\n✅ VALID LOGIN TESTS")
for i, (user, pwd) in enumerate(valid_credentials, 1):
    print(f"\n[Test Case V{i}] Username: {user} | Password: {pwd}")
    login(user, pwd)
    if user == "locked_out_user":
        try:
            assert not is_logged_in(), "❌ Locked out user should NOT be able to log in"
            print("✅ Expected: Login failed (locked out)")
        except AssertionError as e:
            print(str(e))
    else:
        try:
            assert is_logged_in(), f"❌ Valid login failed for {user}"
            print("✅ Login successful")
        except AssertionError as e:
            print(str(e))
    reset_page()

# ---------- Invalid Credentials (10 Tests) ----------
invalid_credentials = [
    ("standard_user", "wrongpass"),
    ("admin", "admin123"),
    ("visual_user", "wrong"),
    ("wrong_user", "secret_sauce"),
    ("guest", "guest123"),
    ("root", "root"),
    ("user", "123456"),
    ("test", "test123"),
    ("problem_user", " "),
    (" ", "secret_sauce")
]

print("\n❌ INVALID LOGIN TESTS")
for i, (user, pwd) in enumerate(invalid_credentials, 1):
    print(f"\n[Test Case I{i}] Username: '{user}' | Password: '{pwd}'")
    login(user, pwd)
    try:
        assert not is_logged_in(), f"❌ Invalid login passed for {user}/{pwd}"
        print("✅ Login failed as expected")
    except AssertionError as e:
        print(str(e))
    reset_page()

# ---------- Empty/Edge Case Tests (4 Tests) ----------
empty_tests = [
    ("", "secret_sauce"),         # Empty username
    ("standard_user", ""),        # Empty password
    ("", ""),                     # Both empty
    ("   ", "   "),               # Whitespace only
]

print("\n⚠️ EMPTY FIELD/EDGE CASE TESTS")
for i, (user, pwd) in enumerate(empty_tests, 1):
    print(f"\n[Test Case E{i}] Username: '{user}' | Password: '{pwd}'")
    login(user, pwd)
    try:
        assert not is_logged_in(), "❌ Login should fail for empty or whitespace input"
        print("✅ Login failed as expected")
    except AssertionError as e:
        print(str(e))
    reset_page()

# Wrap Up 
print("\n🎉 All 20 test cases executed.")
driver.quit()
